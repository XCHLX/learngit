#!/user/local/bin/python2.7
# encoding:utf-8
import sys
import requests
import re
from bs4 import BeautifulSoup
import random
import uuid
import datetime
# 导入 dbHelper 中的类 mySqlHelper
from dbHelper import mySqlHelper
import threading
import time

# 可以User-Agent列表
ua_list = [
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1",
    "Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6",
    "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6",
    "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/19.77.34.5 Safari/537.1",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5",
    "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.36 Safari/536.5",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
    "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3",
    "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.0 Safari/536.3",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24",
    "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24"
]
user_agent = random.choice(ua_list)


def get_random_ip():
    try:
        ipurl = 'http://www.xicidaili.com/nn/'
        ipheaders = {
            'User-Agent': user_agent
        }
        web_data = requests.get(ipurl, headers=ipheaders)
        soup = BeautifulSoup(web_data.text, 'lxml')
        ips = soup.find_all('tr')
        ip_list = []
        for i in range(1, len(ips)):
            ip_info = ips[i]
            tds = ip_info.find_all('td')
            ip_list.append(tds[1].text + ':' + tds[2].text)
        proxy_list = []
        for ip in ip_list:
            proxy_list.append('http://' + ip)
        proxy_ip = random.choice(proxy_list)
        proxies = {'http': proxy_ip}
        return proxies
    except Exception as e:
        return "-1"


def getdsr(sellerid, shopid, proxies):
    try:
        dsrdata = ''
        jsonpid = random.randint(100, 1000)
        url = 'https://shop'+shopid+'.taobao.com'
        headers = {'User-Agent': user_agent,
                   'Host': 'count.taobao.com', 'Referer': url}
        dsrurl = 'https://count.taobao.com/counter3?keys=SM_368_dsr-' + \
            sellerid+'&callback=jsonp'+str(jsonpid)
        s = requests.session()

        if proxies == "-1":
            print('noproxies')
            res = s.get(dsrurl, headers=headers)
        else:
            res = s.get(dsrurl, headers=headers, proxies=proxies)
        content = res.content

        pattern1 = re.compile('m:.*?,')
        mch1 = pattern1.findall(content)
        for item in mch1:
            dsrdata = dsrdata+item.replace("m:", "").replace(",", "")+','
            # print(item.replace("m:", "").replace(",", ""))

        pattern2 = re.compile('[^a-zA-Z]s:.*?,')
        mch2 = pattern2.findall(content)
        for item in mch2:
            dsrdata = dsrdata+item.replace("s:", "").replace(",", "")+','

        pattern3 = re.compile('c:.*?,')
        mch3 = pattern3.findall(content)
        for item in mch3:
            dsrdata = dsrdata+item.replace("c:", "").replace(",", "")

        return dsrdata
    except Exception as e:
        print(e)
        return "-1"


def getData():
    print(datetime.datetime.now())
    try:
        proxies = get_random_ip()
        curtime = datetime.datetime.now().strftime('%Y-%m-%d 00:00:00')
        sql = " select id,shopid from crm_sellerinfo where toolendtime>now() order by lastvisit desc "
        dbmain = mySqlHelper('main')
        results = dbmain.selectall(sql)
        print("total:"+str(len(results)))
        index = 0
        for row in results:
            index += 1
            sellerid = row[0]
            shopid = row[1]
            dsrdata = getdsr(sellerid, shopid, proxies)
            if(dsrdata == "-1"):
                print(sellerid+'  nodata '+str(index))
            else:
                try:
                    tbname = 'crm_score'+sellerid[-2:]  # 截取后两位字符
                    # tbname = 'crm_score'
                    arrdsrdata = dsrdata.split(',')
                    dbtool = mySqlHelper('tools')
                    # 判断当天的数据有没有生成
                    resulttool = dbtool.selectall(
                        " select 1 from "+tbname+" where sellerid='"+sellerid+"' and ctime='"+curtime+"' ")
                    if len(resulttool) > 0:
                        updatesql = " update "+tbname + " set description='" + \
                            arrdsrdata[0]+"',services='"+arrdsrdata[1]+"',logistics='" + \
                            arrdsrdata[2]+"' where sellerid='" + \
                            sellerid+"' and ctime='"+curtime+"'"
                        dbtool.update(updatesql)
                    else:
                        insertsql = " insert into "+tbname + \
                            "(id,sellerid,description,services,logistics,ctime) values('" + \
                            str(uuid.uuid1())+"','"+sellerid+"','" + \
                            arrdsrdata[0]+"','"+arrdsrdata[1]+"','" + \
                            arrdsrdata[2]+"','" + curtime+"')"
                        dbtool.insert(insertsql)
                    print(sellerid+' success '+str(index))
                except Exception as e1:
                    print(e1)
                    print(sellerid + "  " + dsrdata)
    except Exception as e:
        print(e)


if __name__ == "__main__":
    while True:
        getData()
        time.sleep(43200)
