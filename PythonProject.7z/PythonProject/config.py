# encoding:utf-8
#conn = dict(host='114.55.4.22',port = 3306,user='root',passwd = 'BAITAO_taocrm',db ='crm_main',charset = 'utf8')
#conntools = dict(host='114.55.4.22',port = 3306,user='root',passwd = 'BAITAO_taocrm',db ='crm_tools',charset = 'utf8')
#conn = dict(host='jconn2czq3wy9.mysql.rds.aliyuncs.com',port = 3306,user='jusr676isjk7',passwd = 'Y548VbS4Gp9ditdRv5Ghx78mEg4',db ='crm_main',charset = 'utf8')
conntools = dict(host='jconnrdzpdkjp.mysql.rds.aliyuncs.com',port = 3306,user='jusrf9c6cq8k',passwd = 'TBm68T20S4GGbn1Rvbhx7ghEg3r',db ='crm_tools',charset = 'utf8')